package be.pxl.microservices.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.*;

import java.util.List;

@Table(name = "organization")
@Setter
@Getter
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Organization {
    @Id
    private Long id;
    private String name;
    private String address;
    @OneToMany
    private List<Employee> employees;
    @OneToMany
    private List<Department> departments;
}
